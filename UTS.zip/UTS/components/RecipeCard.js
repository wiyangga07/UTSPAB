import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { Center, ScrollView, Spinner } from "@gluestack-ui/themed";
import { useEffect, useState } from "react";

const RecipeCard = ({ recipe }) => {
 const { containerStyle, titleStyle, imageStyle } = styles;

 return (
    <View style={containerStyle}>
      <Image
        source={{ uri: recipe.imageUrl }}
        style={imageStyle}
      />
      <Text style={titleStyle}>{recipe.title}</Text>
    </View>
 );
};

const styles = {
 containerStyle: {
    marginTop: 10,
    marginBottom: 10,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
 },
 titleStyle: {
    fontSize: 18,
    padding: 5,
    alignSelf: 'center',
    color: '#000',
 },
 imageStyle: {
    width: 200,
    height: 200,
 },
};

export default RecipeCard;

