import React from 'react';
import { TextInput, StyleSheet } from 'react-native';
import { Link } from "expo-router";
import { TouchableOpacity } from "react-native";
import { Box, Image, Text, Heading } from "@gluestack-ui/themed";

const InputField = ({ value, onChangeText, placeholder, secureTextEntry }) => {
 const { containerStyle, inputStyle } = styles;

 return (
    <View style={containerStyle}>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        secureTextEntry={secureTextEntry}
        style={inputStyle}
      />
    </View>
 );
};

const styles = {
 containerStyle: {
    marginTop: 10,
    marginBottom: 10,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
 },
 inputStyle: {
    width: 200,
    height: 40,
    paddingLeft: 10,
    borderWidth: 1,
    borderColor: '#1c313a',
    borderRadius: 5,
 },
};

export default InputField;