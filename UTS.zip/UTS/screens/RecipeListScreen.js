import React from 'react';
import { View, Text } from 'react-native';
import RecipeCard from '../components/RecipeCard';

const RecipeScreen = ({ navigation }) => {
 const recipes = [
    { title: 'Recipe 1', imageUrl: 'https://via.placeholder.com/200' },
    { title: 'Recipe 2', imageUrl: 'https://via.placeholder.com/200' },
    { title: 'Recipe 3', imageUrl: 'https://via.placeholder.com/200' },
 ];

 return (
    <View>
      <Text>Recipe List</Text>
      
      {recipes.map((recipe, index) => (
        <RecipeCard key={index} recipe={recipe} />
      ))}
    </View>

 );
};

export default RecipeScreen;