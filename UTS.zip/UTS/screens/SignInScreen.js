import React from 'react';
import { View, Text } from 'react-native';

const SignInScreen = () => {
 return (
    <View>
      <Text>Sign In</Text>
    </View>
 );
};

export default SignInScreen;