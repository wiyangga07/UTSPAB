import React from 'react';
import { View, Text } from 'react-native';

const SignUpScreen = () => {
 return (
    <View>
      <Text>Sign Up</Text>
    </View>
 );
};

export default SignUpScreen;