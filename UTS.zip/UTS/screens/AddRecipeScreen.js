import React from 'react';
import { View, Text } from 'react-native';
import InputField from '../components/InputField';
import Button from '../components/Button';

const AddRecipeScreen = ({ navigation }) => {
 const [title, setTitle] = React.useState('');
 const [ingredients, setIngredients] = React.useState('');
 const [instructions, setInstructions] = React.useState('');

 const handleAddRecipe = () => {
    navigation.navigate('RecipeList', { recipe });
 };

 const recipe = { title, ingredients, instructions };

 return (
    <View>
      <Text>Add Recipe</Text>
      
      <InputField
        value={title}
        onChangeText={setTitle}
        placeholder="Title"
        secureTextEntry={false}
      />
      <InputField
        value={ingredients}
        onChangeText={setIngredients}
        placeholder="Ingredients"
        secureTextEntry={false}
      />
      <InputField
        value={instructions}
        onChangeText={setInstructions}
        placeholder="Instructions"
        secureTextEntry={false}
      />
      <Button onPress={handleAddRecipe} title="Add Recipe" />
    </View>
 );
};

export default AddRecipeScreen;