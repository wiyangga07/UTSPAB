import React from 'react';
import { View, Text } from 'react-native';

const RecipeDetailScreen = ({ route }) => {
 const { recipe } = route.params;

 return (
    <View>
      <Text>Recipe Detail</Text>
      <Text>{recipe.title}</Text>
      <Text>{recipe.ingredients}</Text>
      <Text>{recipe.instructions}</Text>
    </View>
 );
};

export default RecipeDetailScreen;