const dataResep = [
  {
    id: 1,
    image: require('./assets/gambar/1.jpg'),
    NamaResep: "Ayam Goreng Rica-Rica",
    Author: "Wiyangga Khalif ",
    uploadDate: "October 20, 2023",
  },
  {
    id: 2,
    image: require('./assets/gambar/2.jpg'),
    NamaResep: "Ayam Bakar",
    Author: "Unknown",
    uploadDate: "October 19, 2023",
  },
  {
    id: 3,
    image: require('./assets/gambar/3.jpg'),
    NamaResep: "Nasi Bakar",
    Author: "Unknown",
    uploadDate: "October 18, 2023",
  },
  {
    id: 4,
    image: require('./assets/gambar/4.jpg'),
    NamaResep: "Nasi goreng",
    Author: "Unknown",
    uploadDate: "October 17, 2023",
  },
  {
    id: 5,
    image: require('./assets/gambar/5.jpg'),
    NamaResep: "Capcay",
    Author: "Unknown",
    uploadDate: "October 16, 2023",
  },
  
];

export default dataResep;
